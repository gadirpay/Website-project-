import { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CalendarDays, User, Clock, Share2, ChevronRight, ChevronLeft, Facebook, Twitter, Linkedin } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  authorAvatar: string;
  authorRole: string;
  category: string;
  readTime: string;
  image: string;
  slug: string;
  tags: string[];
}

// Sample blog post data
const blogPostData: BlogPost = {
  id: 1,
  title: 'The Importance of Mobile-First Design in 2024',
  excerpt: 'Learn why designing for mobile devices first is crucial for modern websites and how it impacts user experience and search rankings.',
  content: `
    <p>In today's digital landscape, mobile devices are the primary way people access the internet. With over 55% of global web traffic coming from mobile devices, designing for mobile first is no longer optional—it's essential. This approach, known as mobile-first design, prioritizes the mobile user experience before considering desktop layouts.</p>

    <h2>What is Mobile-First Design?</h2>

    <p>Mobile-first design is an approach that starts the design process from the smallest screen size first, then progressively enhances the design for larger screens. This contrasts with the traditional approach of designing for desktop first and then scaling down for mobile devices.</p>

    <p>The philosophy behind mobile-first design is simple: by focusing on the core content and functionality needed on mobile, you ensure that your website delivers the essential experience regardless of device. As screen size increases, you can add more complex elements and features that enhance the experience on larger screens.</p>

    <h2>Why Mobile-First Design Matters in 2024</h2>

    <ol>
      <li>
        <strong>Google's Mobile-First Indexing</strong>
        <p>Since 2019, Google has been using mobile-first indexing, meaning it predominantly uses the mobile version of a website for indexing and ranking. In 2024, websites that aren't optimized for mobile will continue to see negative impacts on their search rankings.</p>
      </li>

      <li>
        <strong>Improved User Experience</strong>
        <p>Mobile users have different needs and behaviors compared to desktop users. They're often on-the-go, have less time, and need information quickly. Mobile-first design ensures your website caters to these needs, providing a seamless experience that keeps users engaged.</p>
      </li>

      <li>
        <strong>Faster Load Times</strong>
        <p>Mobile-first design encourages leaner code and optimized images, resulting in faster-loading websites. This is crucial for mobile users who may have slower internet connections and are more likely to abandon sites that take too long to load.</p>
      </li>

      <li>
        <strong>Future-Proofing</strong>
        <p>As more devices with various screen sizes enter the market, mobile-first design provides a solid foundation for adapting to new technologies. By starting with the most constrained environment, you ensure your website can scale effectively to any device.</p>
      </li>
    </ol>

    <h2>Key Principles of Mobile-First Design</h2>

    <h3>1. Content Prioritization</h3>
    <p>Identify the most important content for your users and make it prominent. On mobile, space is limited, so focus on what's truly essential.</p>

    <h3>2. Simple Navigation</h3>
    <p>Design intuitive navigation that works well with touch interfaces. Hamburger menus, bottom navigation bars, and prominent call-to-action buttons are common patterns that work well on mobile.</p>

    <h3>3. Touch-Friendly Elements</h3>
    <p>Ensure all interactive elements are large enough to be easily tapped with a finger. Apple recommends a minimum target size of 44x44 pixels, while Google suggests 48x48 pixels.</p>

    <h3>4. Progressive Enhancement</h3>
    <p>Start with a basic design that works well on all devices, then add features and complexity for larger screens where appropriate.</p>

    <h3>5. Performance Optimization</h3>
    <p>Optimize images, minimize HTTP requests, and leverage browser caching to ensure your website loads quickly on mobile devices.</p>

    <h2>Implementing Mobile-First Design</h2>

    <p>To implement mobile-first design effectively, start with these steps:</p>

    <ol>
      <li>Begin with mobile wireframes and prototypes before considering larger screens.</li>
      <li>Use CSS media queries with min-width (rather than max-width) to progressively enhance your design for larger screens.</li>
      <li>Test your design on actual mobile devices, not just in browser developer tools.</li>
      <li>Consider the context in which mobile users will be accessing your website.</li>
      <li>Optimize images and other media for mobile by using responsive images and modern formats like WebP.</li>
    </ol>

    <h2>Conclusion</h2>

    <p>In 2024, mobile-first design isn't just a trend—it's a fundamental approach to creating effective websites. By prioritizing the mobile experience, you ensure your website is accessible, user-friendly, and performant for the majority of internet users.</p>

    <p>Remember, mobile-first doesn't mean mobile-only. The goal is to create a responsive experience that works well across all devices while ensuring mobile users aren't treated as an afterthought.</p>

    <p>By embracing mobile-first design principles, you position your website for success in search rankings, user engagement, and future technological changes.</p>
  `,
  date: 'May 18, 2024',
  author: 'David Chen',
  authorAvatar: '',
  authorRole: 'Senior Web Designer',
  category: 'Web Design',
  readTime: '5 min read',
  image: '/images/blog-mobile.jpg',
  slug: 'importance-of-mobile-first-design',
  tags: ['Responsive Design', 'Mobile-First', 'Web Development', 'UX Design', 'SEO'],
};

const recentPosts = [
  {
    id: 2,
    title: '10 Essential SEO Strategies for Small Business Websites',
    date: 'May 12, 2024',
    image: '/images/blog-seo.jpg',
    slug: 'essential-seo-strategies-small-business',
  },
  {
    id: 3,
    title: 'How to Choose the Right E-Commerce Platform for Your Business',
    date: 'May 5, 2024',
    image: '/images/blog-ecommerce.jpg',
    slug: 'choosing-right-ecommerce-platform',
  },
  {
    id: 4,
    title: 'The Future of Web Development: Trends to Watch in 2024',
    date: 'April 28, 2024',
    image: '/images/blog-mobile.jpg',
    slug: 'future-web-development-trends',
  },
];

const BlogPost = () => {
  const { slug } = useParams<{ slug: string }>();

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-[#1b1a21]">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-[#1b1a21]">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center space-x-2 mb-4">
              <Link to="/blog" className="text-primary text-sm font-medium hover:opacity-80">Blog</Link>
              <ChevronRight size={14} className="text-gray-500" />
              <span className="text-gray-400 text-sm">{blogPostData.category}</span>
            </div>

            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              {blogPostData.title}
            </h1>

            <div className="flex flex-wrap items-center text-sm text-gray-400 mb-8 gap-x-6 gap-y-2">
              <div className="flex items-center">
                <CalendarDays size={16} className="mr-2" />
                <span>{blogPostData.date}</span>
              </div>
              <div className="flex items-center">
                <User size={16} className="mr-2" />
                <span>By {blogPostData.author}</span>
              </div>
              <div className="flex items-center">
                <Clock size={16} className="mr-2" />
                <span>{blogPostData.readTime}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-8 bg-[#1b1a21]">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="mb-10 overflow-hidden rounded-lg">
              <img
                src={blogPostData.image}
                alt={blogPostData.title}
                className="w-full h-auto"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              {/* Main Content */}
              <div className="lg:col-span-2">
                <div className="prose prose-invert prose-lg max-w-none prose-headings:text-white prose-p:text-gray-300 prose-strong:text-white prose-li:text-gray-300">
                  <div dangerouslySetInnerHTML={{ __html: blogPostData.content }} />
                </div>

                {/* Tags */}
                <div className="mt-10">
                  <h3 className="text-lg font-bold text-white mb-3">Tags:</h3>
                  <div className="flex flex-wrap gap-2">
                    {blogPostData.tags.map((tag, index) => (
                      <Link
                        key={index}
                        to={`/blog/tag/${tag.toLowerCase().replace(' ', '-')}`}
                        className="bg-[#262630] text-gray-300 hover:bg-gray-800 px-3 py-1 rounded-full text-sm"
                      >
                        {tag}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Share */}
                <div className="mt-8 pt-8 border-t border-gray-800">
                  <h3 className="text-lg font-bold text-white mb-3">Share this article:</h3>
                  <div className="flex space-x-3">
                    <a href="#" className="bg-[#1877F2] text-white p-2 rounded-full hover:bg-[#1877F2]/80">
                      <Facebook size={20} />
                    </a>
                    <a href="#" className="bg-[#1DA1F2] text-white p-2 rounded-full hover:bg-[#1DA1F2]/80">
                      <Twitter size={20} />
                    </a>
                    <a href="#" className="bg-[#0A66C2] text-white p-2 rounded-full hover:bg-[#0A66C2]/80">
                      <Linkedin size={20} />
                    </a>
                    <a href="#" className="bg-[#262630] text-white p-2 rounded-full hover:bg-gray-800">
                      <Share2 size={20} />
                    </a>
                  </div>
                </div>

                {/* Author */}
                <div className="mt-8 p-6 bg-[#262630] rounded-lg border border-gray-800">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={blogPostData.authorAvatar} alt={blogPostData.author} />
                      <AvatarFallback className="bg-primary text-black text-xl">
                        {blogPostData.author.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-bold text-white">{blogPostData.author}</h3>
                      <p className="text-primary text-sm mb-3">{blogPostData.authorRole}</p>
                      <p className="text-gray-400 text-sm">
                        David is a senior web designer with over 10 years of experience in creating responsive, user-friendly websites. He specializes in mobile-first design and user experience optimization.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Navigation */}
                <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link
                    to="/blog/previous-post"
                    className="p-4 bg-[#262630] rounded-lg border border-gray-800 flex items-center hover:bg-gray-800 transition-colors"
                  >
                    <ChevronLeft size={20} className="text-primary mr-2" />
                    <div>
                      <span className="text-gray-400 text-sm block">Previous Post</span>
                      <span className="text-white font-medium">How to Improve Website Load Speed</span>
                    </div>
                  </Link>
                  <Link
                    to="/blog/next-post"
                    className="p-4 bg-[#262630] rounded-lg border border-gray-800 flex items-center justify-end hover:bg-gray-800 transition-colors"
                  >
                    <div className="text-right">
                      <span className="text-gray-400 text-sm block">Next Post</span>
                      <span className="text-white font-medium">Essential SEO Strategies for 2024</span>
                    </div>
                    <ChevronRight size={20} className="text-primary ml-2" />
                  </Link>
                </div>
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                {/* Recent Posts */}
                <div className="mb-10 bg-[#262630] rounded-lg p-6 border border-gray-800">
                  <h3 className="text-xl font-bold text-white mb-4">Recent Posts</h3>
                  <div className="space-y-4">
                    {recentPosts.map(post => (
                      <div key={post.id} className="flex gap-4">
                        <div className="flex-shrink-0 w-20 h-20 overflow-hidden rounded">
                          <img
                            src={post.image}
                            alt={post.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-white hover:text-primary transition-colors line-clamp-2">
                            <Link to={`/blog/${post.slug}`}>{post.title}</Link>
                          </h4>
                          <div className="flex items-center mt-1.5">
                            <CalendarDays size={12} className="text-gray-500 mr-1.5" />
                            <span className="text-xs text-gray-500">{post.date}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Newsletter */}
                <div className="bg-[#262630] rounded-lg p-6 border border-gray-800">
                  <h3 className="text-xl font-bold text-white mb-4">Subscribe to Our Newsletter</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Stay up to date with our latest articles, tips, and insights on web development and design.
                  </p>
                  <div className="space-y-3">
                    <input
                      type="email"
                      className="w-full px-4 py-3 bg-[#1b1a21] border border-gray-700 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Your email address"
                    />
                    <Button className="w-full bg-primary text-black hover:bg-primary/90">
                      Subscribe
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BlogPost;
