import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Hero from '@/components/Hero';
import Services from '@/components/Services';
import Pricing from '@/components/Pricing';
import Contact from '@/components/Contact';
import BlogSection from '@/components/BlogSection';

const Home = () => {
  return (
    <div className="min-h-screen bg-[#1b1a21]">
      <Navbar />
      <Hero />
      <Services />
      <BlogSection />
      <Pricing />
      <Contact />
      <Footer />
    </div>
  );
};

export default Home;
