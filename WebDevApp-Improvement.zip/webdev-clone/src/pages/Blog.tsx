import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CalendarDays, User, Clock, Search, ArrowRight, ChevronRight } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  category: string;
  readTime: string;
  image: string;
  slug: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'The Importance of Mobile-First Design in 2024',
    excerpt: 'Learn why designing for mobile devices first is crucial for modern websites and how it impacts user experience and search rankings.',
    date: 'May 18, 2024',
    author: 'David Chen',
    category: 'Web Design',
    readTime: '5 min read',
    image: '/images/blog-mobile.jpg',
    slug: 'importance-of-mobile-first-design',
  },
  {
    id: 2,
    title: '10 Essential SEO Strategies for Small Business Websites',
    excerpt: 'Discover the most effective SEO techniques that small businesses can implement to improve visibility and attract more organic traffic.',
    date: 'May 12, 2024',
    author: 'Sarah Johnson',
    category: 'SEO',
    readTime: '7 min read',
    image: '/images/blog-seo.jpg',
    slug: 'essential-seo-strategies-small-business',
  },
  {
    id: 3,
    title: 'How to Choose the Right E-Commerce Platform for Your Business',
    excerpt: 'A comprehensive guide to selecting the perfect e-commerce solution based on your specific business needs, budget, and growth plans.',
    date: 'May 5, 2024',
    author: 'Michael Brown',
    category: 'E-Commerce',
    readTime: '6 min read',
    image: '/images/blog-ecommerce.jpg',
    slug: 'choosing-right-ecommerce-platform',
  },
  {
    id: 4,
    title: 'The Future of Web Development: Trends to Watch in 2024',
    excerpt: 'Stay ahead of the curve with the latest web development trends, including AI integration, progressive web apps, and voice user interfaces.',
    date: 'April 28, 2024',
    author: 'Emily Rodriguez',
    category: 'Web Development',
    readTime: '8 min read',
    image: '/images/blog-mobile.jpg',
    slug: 'future-web-development-trends',
  },
  {
    id: 5,
    title: 'How to Create a Content Strategy That Drives Traffic',
    excerpt: 'Learn how to develop a content strategy that attracts visitors, engages your audience, and converts prospects into customers.',
    date: 'April 21, 2024',
    author: 'James Wilson',
    category: 'Content Marketing',
    readTime: '5 min read',
    image: '/images/blog-seo.jpg',
    slug: 'content-strategy-drives-traffic',
  },
  {
    id: 6,
    title: 'Accessibility in Web Design: Making Your Site Inclusive',
    excerpt: 'Understand the importance of web accessibility and learn practical steps to make your website usable for people with various disabilities.',
    date: 'April 15, 2024',
    author: 'Alex Thompson',
    category: 'Web Design',
    readTime: '6 min read',
    image: '/images/blog-ecommerce.jpg',
    slug: 'accessibility-web-design',
  },
];

const categories = [
  { name: 'Web Design', count: 10 },
  { name: 'SEO', count: 8 },
  { name: 'E-Commerce', count: 5 },
  { name: 'Web Development', count: 12 },
  { name: 'Content Marketing', count: 6 },
  { name: 'User Experience', count: 4 },
];

const BlogCard = ({ post }: { post: BlogPost }) => {
  return (
    <Card className="bg-[#262630] border-gray-800 overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative aspect-video overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-primary/90 text-black text-xs font-medium px-2.5 py-1 rounded">
            {post.category}
          </span>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="flex items-center text-sm text-gray-400 mb-3 space-x-4">
          <div className="flex items-center">
            <CalendarDays size={14} className="mr-1.5" />
            <span>{post.date}</span>
          </div>
          <div className="flex items-center">
            <Clock size={14} className="mr-1.5" />
            <span>{post.readTime}</span>
          </div>
        </div>
        <h3 className="text-xl font-bold text-white mb-3 line-clamp-2 hover:text-primary transition-colors">
          <Link to={`/blog/${post.slug}`}>{post.title}</Link>
        </h3>
        <p className="text-gray-400 mb-4 line-clamp-3">{post.excerpt}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <User size={14} className="mr-1.5 text-gray-400" />
            <span className="text-sm text-gray-400">By {post.author}</span>
          </div>
          <Link
            to={`/blog/${post.slug}`}
            className="inline-flex items-center text-primary hover:text-primary/80 font-medium"
          >
            Read More <ArrowRight size={16} className="ml-2" />
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

const Blog = () => {
  return (
    <div className="min-h-screen bg-[#1b1a21]">
      <Navbar />

      {/* Blog Header */}
      <section className="pt-32 pb-16 bg-[#1b1a21]">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Blog</h1>
            <p className="text-gray-400 text-lg mb-10">
              Stay updated with the latest trends, tips, and insights in web development, design, and digital marketing.
            </p>
            <div className="relative max-w-xl mx-auto">
              <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                <Search className="text-gray-500" size={18} />
              </div>
              <input
                type="text"
                className="w-full pl-12 pr-4 py-3 bg-[#262630] border border-gray-700 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Search for articles..."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-16 bg-[#1b1a21]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {blogPosts.map(post => (
                  <BlogCard key={post.id} post={post} />
                ))}
              </div>

              {/* Pagination */}
              <div className="flex justify-center mt-12">
                <div className="flex items-center space-x-2">
                  <Button variant="outline" className="border-gray-700 text-gray-400 hover:bg-gray-800">
                    Previous
                  </Button>
                  <Button className="bg-primary text-black hover:bg-primary/90">1</Button>
                  <Button variant="outline" className="border-gray-700 text-gray-400 hover:bg-gray-800">2</Button>
                  <Button variant="outline" className="border-gray-700 text-gray-400 hover:bg-gray-800">3</Button>
                  <Button variant="outline" className="border-gray-700 text-gray-400 hover:bg-gray-800">
                    Next
                  </Button>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              {/* Categories */}
              <div className="mb-10 bg-[#262630] rounded-lg p-6 border border-gray-800">
                <h3 className="text-xl font-bold text-white mb-4">Categories</h3>
                <ul className="space-y-3">
                  {categories.map((category, index) => (
                    <li key={index}>
                      <Link
                        to={`/blog/category/${category.name.toLowerCase().replace(' ', '-')}`}
                        className="flex items-center justify-between text-gray-400 hover:text-primary transition-colors"
                      >
                        <div className="flex items-center">
                          <ChevronRight size={16} className="mr-2" />
                          <span>{category.name}</span>
                        </div>
                        <span className="text-sm bg-[#1b1a21] px-2 py-1 rounded-full">{category.count}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Recent Posts */}
              <div className="mb-10 bg-[#262630] rounded-lg p-6 border border-gray-800">
                <h3 className="text-xl font-bold text-white mb-4">Recent Posts</h3>
                <div className="space-y-4">
                  {blogPosts.slice(0, 3).map(post => (
                    <div key={post.id} className="flex gap-4">
                      <div className="flex-shrink-0 w-20 h-20 overflow-hidden rounded">
                        <img
                          src={post.image}
                          alt={post.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-white hover:text-primary transition-colors line-clamp-2">
                          <Link to={`/blog/${post.slug}`}>{post.title}</Link>
                        </h4>
                        <div className="flex items-center mt-1.5">
                          <CalendarDays size={12} className="text-gray-500 mr-1.5" />
                          <span className="text-xs text-gray-500">{post.date}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Newsletter */}
              <div className="bg-[#262630] rounded-lg p-6 border border-gray-800">
                <h3 className="text-xl font-bold text-white mb-4">Subscribe to Our Newsletter</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Stay up to date with our latest articles, tips, and insights on web development and design.
                </p>
                <div className="space-y-3">
                  <input
                    type="email"
                    className="w-full px-4 py-3 bg-[#1b1a21] border border-gray-700 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Your email address"
                  />
                  <Button className="w-full bg-primary text-black hover:bg-primary/90">
                    Subscribe
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;
