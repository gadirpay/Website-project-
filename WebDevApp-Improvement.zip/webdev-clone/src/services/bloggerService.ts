import axios from 'axios';

// Google Blogger API interface
const API_KEY = 'YOUR_API_KEY'; // Replace with your actual Google Blogger API key
const BLOG_ID = 'YOUR_BLOG_ID'; // Replace with your actual Blog ID

const baseURL = 'https://www.googleapis.com/blogger/v3';

const bloggerAPI = axios.create({
  baseURL,
  params: {
    key: API_KEY,
  },
});

// Types
export interface BloggerPost {
  id: string;
  kind: string;
  blog: {
    id: string;
  };
  published: string;
  updated: string;
  url: string;
  selfLink: string;
  title: string;
  content: string;
  author: {
    id: string;
    displayName: string;
    url: string;
    image: {
      url: string;
    };
  };
  replies: {
    totalItems: number;
    selfLink: string;
  };
  labels?: string[];
  images?: {
    url: string;
  }[];
}

export interface BloggerPostsResponse {
  kind: string;
  items: BloggerPost[];
  etag: string;
  nextPageToken?: string;
}

export interface BloggerPostRequest {
  pageToken?: string;
  maxResults?: number;
  labels?: string;
}

// API Methods
const bloggerService = {
  // Get blog information
  getBlogInfo: () => {
    return bloggerAPI.get(`/blogs/${BLOG_ID}`);
  },

  // Get all posts with pagination
  getPosts: (params: BloggerPostRequest = {}) => {
    return bloggerAPI.get<BloggerPostsResponse>(`/blogs/${BLOG_ID}/posts`, { params });
  },

  // Get a single post by ID
  getPost: (postId: string) => {
    return bloggerAPI.get<BloggerPost>(`/blogs/${BLOG_ID}/posts/${postId}`);
  },

  // Get posts by label/tag
  getPostsByLabel: (label: string, params: Omit<BloggerPostRequest, 'labels'> = {}) => {
    return bloggerAPI.get<BloggerPostsResponse>(`/blogs/${BLOG_ID}/posts`, {
      params: { ...params, labels: label },
    });
  },

  // Search posts by query
  searchPosts: (query: string, params: BloggerPostRequest = {}) => {
    return bloggerAPI.get<BloggerPostsResponse>(`/blogs/${BLOG_ID}/posts/search`, {
      params: { ...params, q: query },
    });
  },

  // Get comments for a post
  getComments: (postId: string) => {
    return bloggerAPI.get(`/blogs/${BLOG_ID}/posts/${postId}/comments`);
  },
};

export default bloggerService;
