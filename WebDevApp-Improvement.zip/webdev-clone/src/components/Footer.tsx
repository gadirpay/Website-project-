import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#1b1a21] text-white pt-16 pb-8">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and About */}
          <div className="space-y-4">
            <Link to="/" className="inline-block">
              <img src="/images/logo.png" alt="WebDev Logo" className="h-12" />
            </Link>
            <p className="text-gray-400 mt-4">
              Professional web development services tailored to your business needs. We create beautiful, functional websites that help you stand out.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-400 hover:text-primary transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/#services" className="text-gray-400 hover:text-primary transition-colors">Services</Link>
              </li>
              <li>
                <Link to="/#pricing" className="text-gray-400 hover:text-primary transition-colors">Pricing</Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-400 hover:text-primary transition-colors">Blog</Link>
              </li>
              <li>
                <Link to="/#contact" className="text-gray-400 hover:text-primary transition-colors">Contact</Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-6">Our Services</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/#" className="text-gray-400 hover:text-primary transition-colors">Business Websites</Link>
              </li>
              <li>
                <Link to="/#" className="text-gray-400 hover:text-primary transition-colors">E-commerce Solutions</Link>
              </li>
              <li>
                <Link to="/#" className="text-gray-400 hover:text-primary transition-colors">Landing Pages</Link>
              </li>
              <li>
                <Link to="/#" className="text-gray-400 hover:text-primary transition-colors">Portfolio Websites</Link>
              </li>
              <li>
                <Link to="/#" className="text-gray-400 hover:text-primary transition-colors">Custom Web Development</Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="mr-3 text-primary mt-1" size={18} />
                <span className="text-gray-400">DR OUKHRIB ALLAL AIT AMIRA</span>
              </li>
              <li className="flex items-center">
                <Phone className="mr-3 text-primary" size={18} />
                <span className="text-gray-400">(212) 679739362</span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-3 text-primary" size={18} />
                <span className="text-gray-400">wedeveapp@gmail.com</span>
              </li>
            </ul>
            <div className="mt-6">
              <Button asChild className="bg-primary text-dark font-bold hover:bg-primary/90">
                <Link to="/#contact">Get a Quote</Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© 2025. All Rights Reserved By WEBDEV</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <Link to="/privacy-policy" className="text-gray-400 hover:text-primary transition-colors text-sm">Privacy Policy</Link>
              <Link to="/terms-of-service" className="text-gray-400 hover:text-primary transition-colors text-sm">Terms of Service</Link>
              <Link to="/support" className="text-gray-400 hover:text-primary transition-colors text-sm">Support</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
