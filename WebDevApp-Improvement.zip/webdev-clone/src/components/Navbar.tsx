import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-[#1b1a21] shadow-lg py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <img src="/images/logo.png" alt="WebDev Logo" className="h-10" />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-white hover:text-primary transition-colors">Home</Link>
          <Link to="/#services" className="text-white hover:text-primary transition-colors">Services</Link>
          <Link to="/#pricing" className="text-white hover:text-primary transition-colors">Pricing</Link>
          <Link to="/blog" className="text-white hover:text-primary transition-colors">Blog</Link>
          <Link to="/#contact" className="text-white hover:text-primary transition-colors">Contact</Link>
        </nav>

        <div className="hidden md:block">
          <Button asChild className="bg-primary text-dark font-bold hover:bg-primary/90">
            <Link to="/#contact">Get Started</Link>
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-[#1b1a21] py-4">
          <div className="container mx-auto px-4 flex flex-col space-y-4">
            <Link to="/" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Home</Link>
            <Link to="/#services" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Services</Link>
            <Link to="/#pricing" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Pricing</Link>
            <Link to="/blog" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Blog</Link>
            <Link to="/#contact" className="text-white hover:text-primary transition-colors" onClick={() => setIsOpen(false)}>Contact</Link>
            <Button asChild className="bg-primary text-dark font-bold hover:bg-primary/90 w-full">
              <Link to="/#contact" onClick={() => setIsOpen(false)}>Get Started</Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
