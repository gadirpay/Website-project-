import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CalendarDays, User, ArrowRight } from 'lucide-react';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  category: string;
  image: string;
  slug: string;
}

const featuredPosts: BlogPost[] = [
  {
    id: 1,
    title: 'The Importance of Mobile-First Design in 2024',
    excerpt: 'Learn why designing for mobile devices first is crucial for modern websites and how it impacts user experience and search rankings.',
    date: 'May 18, 2024',
    author: 'David Chen',
    category: 'Web Design',
    image: '/images/blog-mobile.jpg',
    slug: 'importance-of-mobile-first-design',
  },
  {
    id: 2,
    title: '10 Essential SEO Strategies for Small Business Websites',
    excerpt: 'Discover the most effective SEO techniques that small businesses can implement to improve visibility and attract more organic traffic.',
    date: 'May 12, 2024',
    author: 'Sarah Johnson',
    category: 'SEO',
    image: '/images/blog-seo.jpg',
    slug: 'essential-seo-strategies-small-business',
  },
  {
    id: 3,
    title: 'How to Choose the Right E-Commerce Platform for Your Business',
    excerpt: 'A comprehensive guide to selecting the perfect e-commerce solution based on your specific business needs, budget, and growth plans.',
    date: 'May 5, 2024',
    author: 'Michael Brown',
    category: 'E-Commerce',
    image: '/images/blog-ecommerce.jpg',
    slug: 'choosing-right-ecommerce-platform',
  },
];

const BlogCard = ({ post }: { post: BlogPost }) => {
  return (
    <Card className="bg-[#262630] border-gray-800 overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative aspect-video overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-primary/90 text-black text-xs font-medium px-2.5 py-1 rounded">
            {post.category}
          </span>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="flex items-center text-sm text-gray-400 mb-3 space-x-4">
          <div className="flex items-center">
            <CalendarDays size={14} className="mr-1.5" />
            <span>{post.date}</span>
          </div>
          <div className="flex items-center">
            <User size={14} className="mr-1.5" />
            <span>{post.author}</span>
          </div>
        </div>
        <h3 className="text-xl font-bold text-white mb-3 line-clamp-2 hover:text-primary transition-colors">
          <Link to={`/blog/${post.slug}`}>{post.title}</Link>
        </h3>
        <p className="text-gray-400 mb-4 line-clamp-3">{post.excerpt}</p>
        <Link
          to={`/blog/${post.slug}`}
          className="inline-flex items-center text-primary hover:text-primary/80 font-medium"
        >
          Read More <ArrowRight size={16} className="ml-2" />
        </Link>
      </CardContent>
    </Card>
  );
};

const BlogSection = () => {
  return (
    <section className="py-20 bg-[#1b1a21]">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <p className="text-[#39afa8] uppercase tracking-wider font-medium mb-2">Our Blog</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white">Latest Web Development Insights</h2>
          </div>
          <div className="mt-4 md:mt-0">
            <Button asChild className="bg-transparent text-white border border-gray-700 hover:bg-gray-800">
              <Link to="/blog">View All Posts</Link>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredPosts.map(post => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
