import { Check, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

interface PricingTier {
  id: number;
  name: string;
  subtitle: string;
  price: {
    current: number;
    original?: number;
  };
  isPopular: boolean;
  features: {
    text: string;
    included: boolean;
  }[];
  cta: string;
}

const pricingTiers: PricingTier[] = [
  {
    id: 1,
    name: "Starter",
    subtitle: "Perfect for small businesses",
    price: {
      current: 199,
      original: 250
    },
    isPopular: false,
    features: [
      { text: "Up to 5 Pages", included: true },
      { text: "Responsive Design", included: true },
      { text: "Basic SEO Setup", included: true },
      { text: "Contact Form Integration", included: true },
      { text: "Social Media Links", included: true },
      { text: "One Revision Round", included: true },
      { text: "Free Domain for 1 Year", included: false },
      { text: "Content Management System", included: false },
      { text: "Performance Optimization", included: false },
      { text: "Post-Launch Support (7 days)", included: true },
    ],
    cta: "Get Started"
  },
  {
    id: 2,
    name: "Business",
    subtitle: "Ideal for growing companies",
    price: {
      current: 449,
      original: 600
    },
    isPopular: true,
    features: [
      { text: "Up to 10 Pages", included: true },
      { text: "Custom Design Layout", included: true },
      { text: "Advanced SEO Optimization", included: true },
      { text: "Blog Setup", included: true },
      { text: "E-Commerce Setup (up to 15 products)", included: true },
      { text: "Google Analytics Integration", included: true },
      { text: "Performance Optimization", included: true },
      { text: "Free Domain for 1 Year", included: true },
      { text: "Content Management System", included: true },
      { text: "Post-Launch Support (30 days)", included: true },
    ],
    cta: "Best Value"
  },
  {
    id: 3,
    name: "Premium",
    subtitle: "Advanced solutions for enterprises",
    price: {
      current: 899,
      original: 1200
    },
    isPopular: false,
    features: [
      { text: "Unlimited Pages", included: true },
      { text: "Complete E-commerce Functionality", included: true },
      { text: "Premium SEO Package", included: true },
      { text: "Multi-language Support", included: true },
      { text: "Advanced Security Setup", included: true },
      { text: "Custom Plugins/Features", included: true },
      { text: "Performance Optimization", included: true },
      { text: "Free Domain for 2 Years", included: true },
      { text: "Advanced Analytics & Reporting", included: true },
      { text: "Priority Support (90 days)", included: true },
    ],
    cta: "Go Premium"
  },
];

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 }
  }
};

const Pricing = () => {
  return (
    <section id="pricing" className="py-24 bg-gradient-to-b from-[#1b1a21] to-[#262630]">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeIn}
        >
          <Badge className="bg-[#39afa8]/20 text-[#39afa8] mb-2 hover:bg-[#39afa8]/30">Limited Time Offer</Badge>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 tracking-tight">
            Simple, Transparent Pricing
          </h2>
          <p className="text-gray-400 text-lg mb-6">
            Choose the plan that works for your business. All plans include a free consultation to discuss your specific needs.
          </p>
          <div className="inline-flex items-center justify-center bg-[#262630] rounded-full p-1.5 border border-gray-700">
            <span className="inline-block px-4 py-2 bg-primary text-black font-medium rounded-full">
              Save up to 25% with our special launch pricing
            </span>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {pricingTiers.map((tier, index) => (
            <motion.div
              key={tier.id}
              className={`relative ${tier.isPopular ? 'md:-mt-6 md:mb-6' : ''}`}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: {
                  opacity: 1,
                  y: 0,
                  transition: {
                    duration: 0.6,
                    delay: index * 0.1
                  }
                }
              }}
            >
              {tier.isPopular && (
                <div className="absolute -top-5 left-0 right-0 mx-auto w-max">
                  <span className="flex items-center gap-1 bg-primary text-black font-medium py-1 px-3 rounded-full text-sm">
                    <Star className="h-3.5 w-3.5 fill-black" /> Most Popular
                  </span>
                </div>
              )}
              <div className={`bg-[#262630] rounded-xl overflow-hidden h-full flex flex-col ${tier.isPopular ? 'border-2 border-primary shadow-lg shadow-primary/10' : 'border border-gray-800'}`}>
                <div className="p-8 pb-4">
                  <h3 className="text-2xl font-bold text-white">{tier.name}</h3>
                  <p className="text-gray-400 mt-1 h-12">{tier.subtitle}</p>

                  <div className="mt-4 mb-6">
                    {tier.price.original && (
                      <span className="text-gray-500 line-through text-lg mr-2">${tier.price.original}</span>
                    )}
                    <span className="text-4xl font-bold text-white">${tier.price.current}</span>
                    <span className="text-gray-400 ml-1">one-time</span>
                  </div>

                  <Button
                    asChild
                    variant={tier.isPopular ? "default" : "outline"}
                    size="lg"
                    className={`w-full ${tier.isPopular ? 'bg-primary text-black hover:bg-primary/90' : 'border-gray-700 text-white hover:bg-gray-800'} font-medium`}
                  >
                    <Link to="/#contact">{tier.cta}</Link>
                  </Button>
                </div>

                <div className="p-8 pt-6 flex-1">
                  <div className="border-t border-gray-800 pt-6">
                    <p className="font-medium text-white mb-4">Includes:</p>
                    <ul className="space-y-3">
                      {tier.features.map((feature, idx) => (
                        <li key={idx} className={`flex items-start gap-3 ${!feature.included ? 'text-gray-500' : 'text-gray-300'}`}>
                          <Check className={`mt-1 h-4 w-4 flex-shrink-0 ${feature.included ? 'text-primary' : 'text-gray-600'}`} />
                          <span className="text-sm">{feature.text}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="bg-[#1b1a21]/40 p-4 text-center">
                  <p className="text-sm text-gray-400">
                    <span className="text-primary font-medium">100% satisfaction</span> guaranteed
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="mt-16 text-center bg-[#262630] rounded-lg p-8 max-w-3xl mx-auto border border-gray-800"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeIn}
        >
          <h3 className="text-xl font-bold text-white mb-2">Need a custom solution?</h3>
          <p className="text-gray-400 mb-6">
            We offer personalized services to meet your specific requirements.
            Contact us for a tailored quote and free consultation.
          </p>
          <Button asChild className="bg-white text-black hover:bg-white/90">
            <Link to="/#contact">Get Custom Quote</Link>
          </Button>
        </motion.div>

        <motion.div
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeIn}
        >
          <div className="bg-[#262630]/50 rounded-lg p-6 flex flex-col items-center text-center">
            <div className="rounded-full bg-primary/10 p-3 mb-4">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
                <path d="M12 6V18M6 12H18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Money-Back Guarantee</h3>
            <p className="text-gray-400 text-sm">Not satisfied? Get a full refund within 14 days, no questions asked.</p>
          </div>

          <div className="bg-[#262630]/50 rounded-lg p-6 flex flex-col items-center text-center">
            <div className="rounded-full bg-primary/10 p-3 mb-4">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
                <path d="M3 10H21M7 15H8M12 15H13M17 15H18M6 19H18C19.1046 19 20 18.1046 20 17V9C20 7.89543 19.1046 7 18 7H6C4.89543 7 4 7.89543 4 9V17C4 18.1046 4.89543 19 6 19Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Secure Payments</h3>
            <p className="text-gray-400 text-sm">Your payment information is always secure and encrypted.</p>
          </div>

          <div className="bg-[#262630]/50 rounded-lg p-6 flex flex-col items-center text-center">
            <div className="rounded-full bg-primary/10 p-3 mb-4">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
                <path d="M15 10L19.5528 7.72361C19.8343 7.58281 20.1852 7.84093 20.1316 8.15l-1.1056 6.2756C19.5056 15.5894 19.9819 15.9909 20.1056 16M9 10L4.44721 7.72361C4.16569 7.58281 3.81476 7.84093 3.86845 8.15l1.1056 6.2756C4.4944 15.5894 4.01815 15.9909 3.89443 16M12 8C12.5523 8 13 7.55228 13 7C13 6.44772 12.5523 6 12 6C11.4477 6 11 6.44772 11 7C11 7.55228 11.4477 8 12 8ZM12 8V14M12 14C12.5523 14 13 14.4477 13 15C13 15.5523 12.5523 16 12 16C11.4477 16 11 15.5523 11 15C11 14.4477 11.4477 14 12 14Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Ongoing Support</h3>
            <p className="text-gray-400 text-sm">Dedicated assistance during and after your project completion.</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;
