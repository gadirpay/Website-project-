import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 pb-16 overflow-hidden bg-[#1b1a21]">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1b1a21]/90 to-[#1b1a21]/70"></div>
        <div className="absolute inset-0 bg-[url('/images/code-bg.jpg')] bg-cover bg-center opacity-40"></div>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-white space-y-6">
            <span className="inline-block bg-[#39afa8]/20 text-[#39afa8] text-sm font-medium py-1 px-3 rounded-full mb-2">
              Tailored Solutions
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Build Your Brand with <span className="text-primary">Custom Websites</span>
            </h1>
            <p className="text-gray-300 text-lg max-w-lg">
              Transform your online presence with professional web development solutions tailored to your business needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button asChild size="lg" className="bg-primary text-dark font-bold hover:bg-primary/90">
                <Link to="/#contact">GET STARTED</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
                <Link to="/#services">Our Services</Link>
              </Button>
            </div>
          </div>

          <div className="flex justify-center lg:justify-end relative">
            <div className="relative">
              <img
                src="/images/slider_img.png"
                alt="Web Development"
                className="z-10 relative animate-float max-w-full h-auto"
              />
              <div className="absolute -bottom-4 left-0 right-0 mx-auto w-4/5 h-8 bg-black/20 blur-xl rounded-full"></div>
            </div>
            <div className="absolute bottom-0 right-0 flex items-center space-x-4">
              <img src="/images/flutter.svg" alt="Flutter" className="h-12 opacity-80" />
              <img src="/images/html5-js-css3.png" alt="HTML, JS, CSS" className="h-12 opacity-80" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
