import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, Mail } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectName: '',
    website: '',
    description: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would handle form submission here
    console.log('Form submitted:', formData);
    // Reset form
    setFormData({
      name: '',
      email: '',
      projectName: '',
      website: '',
      description: '',
    });
    alert('Thank you for your message! We will get back to you soon.');
  };

  return (
    <section id="contact" className="py-16 bg-[#1b1a21]">
      <div className="container mx-auto px-4">
        <div className="w-full text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Get Started with a Free Consultation
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Enter your email to explore how my web development services can enhance your online presence.
          </p>
        </div>

        <div className="bg-primary py-8 px-6 rounded-lg mb-16">
          <div className="flex flex-col md:flex-row gap-4 max-w-3xl mx-auto">
            <Input
              type="email"
              placeholder="Your email address"
              className="bg-white text-black flex-1"
            />
            <Button
              className="bg-black text-white hover:bg-black/80 font-medium"
            >
              GET STARTED
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <h3 className="text-xl font-bold text-white mb-6">Get a Quote</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Input
                    type="text"
                    name="name"
                    placeholder="Your Name *"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="bg-[#262630] border-gray-700 text-white"
                  />
                </div>
                <div>
                  <Input
                    type="email"
                    name="email"
                    placeholder="Your Email *"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="bg-[#262630] border-gray-700 text-white"
                  />
                </div>
              </div>

              <div>
                <Input
                  type="text"
                  name="projectName"
                  placeholder="Project Name *"
                  value={formData.projectName}
                  onChange={handleChange}
                  required
                  className="bg-[#262630] border-gray-700 text-white"
                />
              </div>

              <div>
                <Input
                  type="text"
                  name="website"
                  placeholder="Your Website (if any)"
                  value={formData.website}
                  onChange={handleChange}
                  className="bg-[#262630] border-gray-700 text-white"
                />
              </div>

              <div>
                <Textarea
                  name="description"
                  placeholder="Describe Your Project (e.g. website type, features needed, timeframe, budget)"
                  value={formData.description}
                  onChange={handleChange}
                  required
                  className="bg-[#262630] border-gray-700 text-white min-h-[150px]"
                />
              </div>

              <div>
                <Button
                  type="submit"
                  className="bg-primary text-black hover:bg-primary/90 font-medium px-8"
                >
                  SUBMIT A QUOTE
                </Button>
              </div>
            </form>
          </div>

          <div>
            <h3 className="text-xl font-bold text-white mb-6">Information</h3>
            <p className="text-gray-400 mb-6">
              Need help? Let us know what you need for your project, and we'll provide the best solution.
            </p>

            <div className="space-y-6">
              <div className="flex items-start">
                <MapPin className="text-primary mt-1 mr-3" size={22} />
                <p className="text-gray-400">
                  DR OUKHRIB ALLAL AIT AMIRA
                </p>
              </div>

              <div className="flex items-start">
                <Phone className="text-primary mt-1 mr-3" size={22} />
                <p className="text-gray-400">
                  (212) 679739362
                </p>
              </div>

              <div className="flex items-start">
                <Mail className="text-primary mt-1 mr-3" size={22} />
                <p className="text-gray-400">
                  wedeveapp@gmail.com
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
