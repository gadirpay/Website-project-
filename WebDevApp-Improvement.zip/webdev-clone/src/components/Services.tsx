import { CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface ServiceItemProps {
  id: number;
  title: string;
  year: string;
  tag: string;
  duration: string;
  rating: string;
  image: string;
}

const serviceItems: ServiceItemProps[] = [
  {
    id: 1,
    title: 'Business Website',
    year: '2024',
    tag: 'Professional',
    duration: '2-4 weeks',
    rating: '4.9',
    image: '/images/portfolio1.png',
  },
  {
    id: 2,
    title: 'E-commerce Website',
    year: '2024',
    tag: 'Secure Payments',
    duration: '3-6 weeks',
    rating: '4.8',
    image: '/images/portfolio2.png',
  },
  {
    id: 3,
    title: 'Portfolio Website',
    year: '2024',
    tag: 'Creative',
    duration: '1-3 weeks',
    rating: '5.0',
    image: '/images/portfolio3.png',
  },
  {
    id: 4,
    title: 'Educational Website',
    year: '2024',
    tag: 'Interactive',
    duration: '4-8 weeks',
    rating: '4.7',
    image: '/images/portfolio4.png',
  },
  {
    id: 5,
    title: 'Blog Website',
    year: '2024',
    tag: 'Engaging Content',
    duration: '2-3 weeks',
    rating: '4.9',
    image: '/images/portfolio1.png',
  },
  {
    id: 6,
    title: 'Beauty Web',
    year: '2024',
    tag: 'Interactive',
    duration: '6-12 weeks',
    rating: '5.0',
    image: '/images/portfolio2.png',
  },
  {
    id: 7,
    title: 'Landing Page',
    year: '2024',
    tag: 'High Conversion',
    duration: '1-2 weeks',
    rating: '4.9',
    image: '/images/portfolio3.png',
  },
  {
    id: 8,
    title: 'Government Website',
    year: '2024',
    tag: 'Public Services',
    duration: '6-10 weeks',
    rating: '4.9',
    image: '/images/portfolio4.png',
  },
  {
    id: 9,
    title: 'Booking Website',
    year: '2024',
    tag: 'Efficient Scheduling',
    duration: '4-8 weeks',
    rating: '4.8',
    image: '/images/portfolio1.png',
  },
];

const ServiceItem = ({ title, year, tag, duration, rating, image }: ServiceItemProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow bg-[#1b1a21] border-gray-800">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img src={image} alt={title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-white mb-1">{title}</h3>
        <div className="flex justify-between items-center text-sm mt-3">
          <span className="text-primary">{year}</span>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">{tag}</span>
            <span className="text-gray-400">•</span>
            <span className="text-gray-400">{duration}</span>
          </div>
          <div className="flex items-center space-x-1">
            <span className="text-yellow-400">★</span>
            <span className="text-gray-400">{rating}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const Services = () => {
  return (
    <section id="services" className="py-20 bg-[#1b1a21]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-[#39afa8] uppercase font-medium tracking-wider mb-2">WEB DEVELOPMENT SERVICES</p>
          <h2 className="text-3xl md:text-4xl font-bold text-white">Professional Website Creation</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {serviceItems.map((service) => (
            <ServiceItem key={service.id} {...service} />
          ))}
        </div>

        <div className="mt-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="lg:order-2">
            <img src="/images/web_development.png" alt="Professional Development" className="w-full max-w-lg mx-auto" />
          </div>
          <div className="lg:order-1">
            <p className="text-[#39afa8] uppercase font-medium tracking-wider mb-2">PROFESSIONAL DEVELOPMENT</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-8">Elevate Your Business with Expert Web Solutions</h2>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="text-primary mt-1">
                  <CheckCircle size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-1">Custom Web Design</h3>
                  <p className="text-gray-400">Transform your vision into a beautiful, functional website tailored to your needs.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="text-primary mt-1">
                  <CheckCircle size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-1">Responsive Everywhere</h3>
                  <p className="text-gray-400">Your website will be optimized for all devices, ensuring a seamless experience.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="text-primary mt-1">
                  <CheckCircle size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-1">SEO Optimization</h3>
                  <p className="text-gray-400">Improve your search engine ranking with our comprehensive SEO strategies.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="text-primary mt-1">
                  <CheckCircle size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-1">Fast Performance</h3>
                  <p className="text-gray-400">Enjoy lightning-fast loading times and smooth user experience.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
