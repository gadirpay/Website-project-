import { ComponentType, ReactNode } from 'react';
import { Badge } from "@/components/ui/badge";

export interface Badge {
  id: number;
  label: string;
  className?: string;
}

export interface ServiceItemInterface {
  id: number;
  title: string;
  year: string;
  tag: string;
  duration: string;
  rating: string;
  image: string;
  description?: string;
  badges?: Badge[];
  features?: string[];
  showAction?: boolean;
}

export interface PricingPlan {
  id: number;
  name: string;
  subtitle: string;
  price: {
    current: number;
    original?: number;
  };
  isPopular: boolean;
  features: {
    text: string;
    included: boolean;
  }[];
  cta: string;
}

export interface BloggerPost {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  published: string;
  author: {
    displayName: string;
    image?: {
      url: string;
    };
  };
  url: string;
  labels?: string[];
  images?: {
    url: string;
  }[];
}

export interface NavItem {
  title: string;
  href: string;
  isExternal?: boolean;
  children?: NavItem[];
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  content: string;
  avatar?: string;
  rating: number;
}

export interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
  client: string;
  date: string;
  tags: string[];
  link?: string;
}

// Main navigation items
export const navItems: NavItem[] = [
  {
    title: 'Home',
    href: '/',
  },
  {
    title: 'Services',
    href: '/#services',
  },
  {
    title: 'Portfolio',
    href: '/portfolio',
  },
  {
    title: 'Blog',
    href: '/blog',
  },
  {
    title: 'Pricing',
    href: '/#pricing',
  },
  {
    title: 'About',
    href: '/about',
  },
  {
    title: 'Contact',
    href: '/#contact',
  },
];

// Services data
export const serviceItems: ServiceItemInterface[] = [
  {
    id: 1,
    title: 'Business Website',
    year: '2024',
    tag: 'Professional',
    duration: '2-4 weeks',
    rating: '4.9',
    image: '/images/portfolio1.png',
    description: 'A complete business website solution with modern design, optimized for conversions and brand visibility.',
    badges: [
      { id: 1, label: 'Responsive', className: 'bg-blue-500/20 text-blue-500' },
      { id: 2, label: 'SEO-Ready', className: 'bg-green-500/20 text-green-500' }
    ],
    features: [
      'Professional design tailored to your brand',
      'Mobile-responsive layout',
      'Contact forms and business information',
      'Services/products showcase',
      'Basic SEO optimization'
    ],
    showAction: true
  },
  {
    id: 2,
    title: 'E-commerce Website',
    year: '2024',
    tag: 'Secure Payments',
    duration: '3-6 weeks',
    rating: '4.8',
    image: '/images/portfolio2.png',
    description: 'Comprehensive online store solution with secure payment processing and inventory management.',
    badges: [
      { id: 1, label: 'E-Commerce', className: 'bg-purple-500/20 text-purple-500' },
      { id: 2, label: 'Secure', className: 'bg-red-500/20 text-red-500' }
    ],
    features: [
      'Product catalog and management',
      'Secure payment processing',
      'Customer accounts',
      'Order tracking',
      'Inventory management'
    ],
    showAction: true
  },
  {
    id: 3,
    title: 'Portfolio Website',
    year: '2024',
    tag: 'Creative',
    duration: '1-3 weeks',
    rating: '5.0',
    image: '/images/portfolio3.png',
    description: 'Showcase your work with an elegant, modern portfolio website designed to highlight your achievements.',
    badges: [
      { id: 1, label: 'Creative', className: 'bg-yellow-500/20 text-yellow-500' },
      { id: 2, label: 'Gallery', className: 'bg-teal-500/20 text-teal-500' }
    ],
    features: [
      'Project showcasing',
      'Visual galleries',
      'Testimonials section',
      'About me/company page',
      'Contact information'
    ],
    showAction: true
  },
  {
    id: 4,
    title: 'Educational Website',
    year: '2024',
    tag: 'Interactive',
    duration: '4-8 weeks',
    rating: '4.7',
    image: '/images/portfolio4.png',
    description: 'Comprehensive educational platform with course management, student dashboards, and learning tools.',
    badges: [
      { id: 1, label: 'E-Learning', className: 'bg-indigo-500/20 text-indigo-500' },
      { id: 2, label: 'Interactive', className: 'bg-pink-500/20 text-pink-500' }
    ],
    showAction: true
  },
  {
    id: 5,
    title: 'Blog Website',
    year: '2024',
    tag: 'Engaging Content',
    duration: '2-3 weeks',
    rating: '4.9',
    image: '/images/portfolio1.png',
    description: 'Professional blogging platform with content management, categories, and engaging reader features.',
    badges: [
      { id: 1, label: 'Content', className: 'bg-orange-500/20 text-orange-500' },
      { id: 2, label: 'SEO', className: 'bg-green-500/20 text-green-500' }
    ],
    showAction: true
  },
  {
    id: 6,
    title: 'Beauty Web',
    year: '2024',
    tag: 'Interactive',
    duration: '6-12 weeks',
    rating: '5.0',
    image: '/images/portfolio2.png',
    description: 'Elegant website design for beauty brands, featuring product showcases and service bookings.',
    badges: [
      { id: 1, label: 'Elegant', className: 'bg-pink-500/20 text-pink-500' },
      { id: 2, label: 'Booking', className: 'bg-purple-500/20 text-purple-500' }
    ],
    showAction: true
  },
  {
    id: 7,
    title: 'Landing Page',
    year: '2024',
    tag: 'High Conversion',
    duration: '1-2 weeks',
    rating: '4.9',
    image: '/images/portfolio3.png',
    description: 'High-converting landing pages designed to maximize leads and sales for your campaigns.',
    badges: [
      { id: 1, label: 'Conversion', className: 'bg-green-500/20 text-green-500' },
      { id: 2, label: 'Fast', className: 'bg-blue-500/20 text-blue-500' }
    ],
    showAction: true
  },
  {
    id: 8,
    title: 'Government Website',
    year: '2024',
    tag: 'Public Services',
    duration: '6-10 weeks',
    rating: '4.9',
    image: '/images/portfolio4.png',
    description: 'Accessible and compliant websites for government agencies and public service organizations.',
    badges: [
      { id: 1, label: 'Accessible', className: 'bg-blue-500/20 text-blue-500' },
      { id: 2, label: 'Compliant', className: 'bg-red-500/20 text-red-500' }
    ],
    showAction: true
  },
  {
    id: 9,
    title: 'Booking Website',
    year: '2024',
    tag: 'Efficient Scheduling',
    duration: '4-8 weeks',
    rating: '4.8',
    image: '/images/portfolio1.png',
    description: 'Streamlined booking and reservation system for appointments, events, or services.',
    badges: [
      { id: 1, label: 'Booking', className: 'bg-teal-500/20 text-teal-500' },
      { id: 2, label: 'Calendar', className: 'bg-indigo-500/20 text-indigo-500' }
    ],
    showAction: true
  },
];

// Pricing plans
export const pricingPlans: PricingPlan[] = [
  {
    id: 1,
    name: "Starter",
    subtitle: "Perfect for small businesses",
    price: {
      current: 199,
      original: 250
    },
    isPopular: false,
    features: [
      { text: "Up to 5 Pages", included: true },
      { text: "Responsive Design", included: true },
      { text: "Basic SEO Setup", included: true },
      { text: "Contact Form Integration", included: true },
      { text: "Social Media Links", included: true },
      { text: "One Revision Round", included: true },
      { text: "Free Domain for 1 Year", included: false },
      { text: "Content Management System", included: false },
      { text: "Performance Optimization", included: false },
      { text: "Post-Launch Support (7 days)", included: true },
    ],
    cta: "Get Started"
  },
  {
    id: 2,
    name: "Business",
    subtitle: "Ideal for growing companies",
    price: {
      current: 449,
      original: 600
    },
    isPopular: true,
    features: [
      { text: "Up to 10 Pages", included: true },
      { text: "Custom Design Layout", included: true },
      { text: "Advanced SEO Optimization", included: true },
      { text: "Blog Setup", included: true },
      { text: "E-Commerce Setup (up to 15 products)", included: true },
      { text: "Google Analytics Integration", included: true },
      { text: "Performance Optimization", included: true },
      { text: "Free Domain for 1 Year", included: true },
      { text: "Content Management System", included: true },
      { text: "Post-Launch Support (30 days)", included: true },
    ],
    cta: "Best Value"
  },
  {
    id: 3,
    name: "Premium",
    subtitle: "Advanced solutions for enterprises",
    price: {
      current: 899,
      original: 1200
    },
    isPopular: false,
    features: [
      { text: "Unlimited Pages", included: true },
      { text: "Complete E-commerce Functionality", included: true },
      { text: "Premium SEO Package", included: true },
      { text: "Multi-language Support", included: true },
      { text: "Advanced Security Setup", included: true },
      { text: "Custom Plugins/Features", included: true },
      { text: "Performance Optimization", included: true },
      { text: "Free Domain for 2 Years", included: true },
      { text: "Advanced Analytics & Reporting", included: true },
      { text: "Priority Support (90 days)", included: true },
    ],
    cta: "Go Premium"
  },
];

// Blog categories
export const blogCategories = [
  { name: 'Web Design', count: 10 },
  { name: 'SEO', count: 8 },
  { name: 'E-Commerce', count: 5 },
  { name: 'Web Development', count: 12 },
  { name: 'Content Marketing', count: 6 },
  { name: 'User Experience', count: 4 },
];

// Sample blog posts
export const blogPosts = [
  {
    id: 1,
    title: 'The Importance of Mobile-First Design in 2024',
    excerpt: 'Learn why designing for mobile devices first is crucial for modern websites and how it impacts user experience and search rankings.',
    date: 'May 18, 2024',
    author: 'David Chen',
    category: 'Web Design',
    readTime: '5 min read',
    image: '/images/blog-mobile.jpg',
    slug: 'importance-of-mobile-first-design',
  },
  {
    id: 2,
    title: '10 Essential SEO Strategies for Small Business Websites',
    excerpt: 'Discover the most effective SEO techniques that small businesses can implement to improve visibility and attract more organic traffic.',
    date: 'May 12, 2024',
    author: 'Sarah Johnson',
    category: 'SEO',
    readTime: '7 min read',
    image: '/images/blog-seo.jpg',
    slug: 'essential-seo-strategies-small-business',
  },
  {
    id: 3,
    title: 'How to Choose the Right E-Commerce Platform for Your Business',
    excerpt: 'A comprehensive guide to selecting the perfect e-commerce solution based on your specific business needs, budget, and growth plans.',
    date: 'May 5, 2024',
    author: 'Michael Brown',
    category: 'E-Commerce',
    readTime: '6 min read',
    image: '/images/blog-ecommerce.jpg',
    slug: 'choosing-right-ecommerce-platform',
  },
  {
    id: 4,
    title: 'The Future of Web Development: Trends to Watch in 2024',
    excerpt: 'Stay ahead of the curve with the latest web development trends, including AI integration, progressive web apps, and voice user interfaces.',
    date: 'April 28, 2024',
    author: 'Emily Rodriguez',
    category: 'Web Development',
    readTime: '8 min read',
    image: '/images/blog-mobile.jpg',
    slug: 'future-web-development-trends',
  },
  {
    id: 5,
    title: 'How to Create a Content Strategy That Drives Traffic',
    excerpt: 'Learn how to develop a content strategy that attracts visitors, engages your audience, and converts prospects into customers.',
    date: 'April 21, 2024',
    author: 'James Wilson',
    category: 'Content Marketing',
    readTime: '5 min read',
    image: '/images/blog-seo.jpg',
    slug: 'content-strategy-drives-traffic',
  },
  {
    id: 6,
    title: 'Accessibility in Web Design: Making Your Site Inclusive',
    excerpt: 'Understand the importance of web accessibility and learn practical steps to make your website usable for people with various disabilities.',
    date: 'April 15, 2024',
    author: 'Alex Thompson',
    category: 'Web Design',
    readTime: '6 min read',
    image: '/images/blog-ecommerce.jpg',
    slug: 'accessibility-web-design',
  },
];

// Testimonials
export const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'CEO',
    company: 'TechStart LLC',
    content: 'Working with WebDev was a game-changer for our business. Their team delivered a beautiful, functional website that perfectly represents our brand. The attention to detail and responsiveness throughout the project was exceptional.',
    rating: 5
  },
  {
    id: 2,
    name: 'Michael Rodriguez',
    role: 'Marketing Director',
    company: 'Global Retail Solutions',
    content: 'Our e-commerce site needed a complete overhaul, and WebDev delivered beyond our expectations. Sales have increased by 35% since the new site launched, and the user experience feedback has been overwhelmingly positive.',
    rating: 5
  },
  {
    id: 3,
    name: 'Emily Chen',
    role: 'Small Business Owner',
    company: 'Artisan Crafts',
    content: 'As a small business owner, I needed an affordable but professional website. WebDev provided exactly what I needed within my budget and were patient with all my questions. The finished site has helped me reach new customers nationwide.',
    rating: 4
  },
  {
    id: 4,
    name: 'David Williams',
    role: 'CTO',
    company: 'Innovate Finance',
    content: 'The technical expertise at WebDev is impressive. They built a complex web application for our financial services with excellent attention to security and performance. The ongoing support has been reliable and responsive.',
    rating: 5
  },
  {
    id: 5,
    name: 'Lisa Thompson',
    role: 'Content Manager',
    company: 'Educational Insights',
    content: 'Our educational platform required specific features for course management and student engagement. WebDev understood our requirements perfectly and created an intuitive platform that both instructors and students love using.',
    rating: 4
  },
];

// Portfolio projects
export const portfolioProjects: PortfolioItem[] = [
  {
    id: 1,
    title: 'Modern E-commerce Platform',
    category: 'E-commerce',
    image: '/images/portfolio1.png',
    description: 'A comprehensive e-commerce solution built for a fashion retailer, featuring product management, secure payments, and customer accounts.',
    client: 'Fashion Forward Inc.',
    date: 'April 2024',
    tags: ['E-commerce', 'React', 'Node.js', 'Stripe'],
    link: 'https://example.com/project1'
  },
  {
    id: 2,
    title: 'Corporate Website Redesign',
    category: 'Business',
    image: '/images/portfolio2.png',
    description: 'Complete redesign of a corporate website for a financial services company, focusing on brand consistency and lead generation.',
    client: 'Global Financial Services',
    date: 'March 2024',
    tags: ['Corporate', 'WordPress', 'SEO', 'Responsive'],
    link: 'https://example.com/project2'
  },
  {
    id: 3,
    title: 'Educational Learning Platform',
    category: 'Educational',
    image: '/images/portfolio3.png',
    description: 'Interactive learning platform with course management, student progress tracking, and integrated assessment tools.',
    client: 'EduTech Solutions',
    date: 'February 2024',
    tags: ['Education', 'React', 'Firebase', 'LMS'],
    link: 'https://example.com/project3'
  },
  {
    id: 4,
    title: 'Restaurant Booking System',
    category: 'Booking',
    image: '/images/portfolio4.png',
    description: 'Online reservation system for a chain of restaurants, with table management, customer profiles, and automated notifications.',
    client: 'Gourmet Restaurant Group',
    date: 'January 2024',
    tags: ['Booking', 'React', 'Node.js', 'MongoDB'],
    link: 'https://example.com/project4'
  },
  {
    id: 5,
    title: 'Healthcare Provider Portal',
    category: 'Healthcare',
    image: '/images/portfolio2.png',
    description: 'Secure patient portal for a healthcare provider, allowing appointment scheduling, medical record access, and secure messaging.',
    client: 'MedCare Health Network',
    date: 'December 2023',
    tags: ['Healthcare', 'Security', 'React', 'Express'],
    link: 'https://example.com/project5'
  },
  {
    id: 6,
    title: 'Real Estate Listings Platform',
    category: 'Real Estate',
    image: '/images/portfolio3.png',
    description: 'Property listings website with advanced search, virtual tours, and agent contact features for a real estate agency.',
    client: 'Prime Properties',
    date: 'November 2023',
    tags: ['Real Estate', 'Maps API', 'Filtering', 'Gallery'],
    link: 'https://example.com/project6'
  },
];
